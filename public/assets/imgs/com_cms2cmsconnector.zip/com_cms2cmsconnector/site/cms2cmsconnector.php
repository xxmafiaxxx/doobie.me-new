<?php
/**
 * @copyright	Copyright (C) 2013 - 2017 Cms2Cms. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
