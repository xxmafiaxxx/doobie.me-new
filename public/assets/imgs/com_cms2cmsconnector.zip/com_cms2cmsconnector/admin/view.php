<?php
/**
 * @copyright	Copyright (C) 2013 - 2017 Cms2Cms. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

class CmsPluginView
{
    private $jsConfig = '{
        "host"         : "https://app.cms2cms.com",
        "youtube"      : "http://www.youtube.com/watch?feature=player_detailpage&v=DQK01NbrCdw#t=25s",
        "feedback"     : "http://cms2cms.polldaddy.com/s/survey",
        "support"      : "//support.magneticone.com/visitor/index.php?/Default/LiveChat/Chat/Request/_sessionID=/_promptType=chat/_proactive=0/_filterDepartmentID=55/_randomNumber=bnkpattsb316qulj4o15lvdbkq6qsw53",
        "wizard"      : "https://app.cms2cms.com/wizard",
        "facebook"    : "//www.facebook.com/Cms2Cms/",
        "twitter"     : "//twitter.com/cms2cms",
        "wp_feedback" : "//extensions.joomla.org/extensions/extension/migration-a-conversion/data-import-a-export/cms2cms-automated-wordpress-to-j-migration/#reviews",
        "public_host" : "//www.cms2cms.com",
        "bridge"      : "https://app.cms2cms.com/bridge/download",
        "ticket"      : "//support.magneticone.com/index.php?/Tickets/Submit/RenderForm/56",
        "logout"      : "https://app.cms2cms.com/auth/logout",
        "auth_check"  : "https://app.cms2cms.com/api/auth-check"
    }';

    private $config = array (
        'host'        => 'https://app.cms2cms.com',
        'youtube'     => 'http://www.youtube.com/watch?feature=player_detailpage&v=DQK01NbrCdw#t=25s',
        'feedback'    => 'http://cms2cms.polldaddy.com/s/survey',
        'support'     => '//support.magneticone.com/visitor/indexp.hp?/Default/LiveChat/Chat/Request/_sessionID=
                    /_promptType=cht/_proactive=0/_filterDepartmentID=55/_randomNumber=bnkpattsb316qulj4o15lvdbkq6qsw53',
        'wizard'      => 'https://app.cms2cms.com/wizard',
        'facebook'    => '//www.facebook.com/Cms2Cms/',
        'twitter'     => '//twitter.com/cms2cms',
        'wp_feedback' => '//extensions.joomla.org/extensions/extension/migration-a-conversion/data-import-a-export/cms2cms-automated-wordpress-to-j-migration/#reviews',
        'public_host' => '//www.cms2cms.com',
        'bridge'      => 'https://app.cms2cms.com/bridge/download',
        'ticket'      => '//support.magneticone.com/index.php?/Tickets/Submit/RenderForm/56',
        'logout'      => 'https://app.cms2cms.com/auth/logout',
        'auth_check'  => 'https://app.cms2cms.com/api/auth-check'
    );

    /**
     * Get app url
     * @param bool $json Json return
     * @return string
     */
    public function getConfig($json = false)
    {
        return  $json ? $this->jsConfig : $this->config;
    }

    public function getAppUrl()
    {
        $config = $this->getConfig();

        return $config['host'];
    }

    public function getVideoLink()
    {
        return 'http://www.youtube.com/watch?feature=player_detailpage&v=DQK01NbrCdw#t=25s';
    }

    public function getPluginSourceName()
    {
        return 'Connector';
    }

    public function getPluginSourceType()
    {
        return 'Connector';
    }

    public function getPluginTargetName()
    {
        return 'Joomla';
    }

    public function getPluginTargetType()
    {
        return 'Joomla';
    }

    public function getPluginNameLong()
    {
        return sprintf(
            'CMS2CMS:  %s ',
            $this->getPluginSourceName()
        );
    }

    public function getPluginNameShort()
    {
        return sprintf('connectortoj3', $this->getPluginSourceName(), $this->getPluginTargetName());
    }

    public function getPluginReferrerId()
    {
        return sprintf(
            'Plugin | %s | %s to %s',
            $this->getPluginTargetType(),
            $this->getPluginSourceType(),
            $this->getPluginTargetType()
        );
    }

    public function getRegisterUrl()
    {
        return $this->getAppUrl() . '/auth/sign-up';
    }

    public function getLoginUrl()
    {
        return $this->getAppUrl() . '/auth/sign-in';
    }

    public function getLogOutUrl()
    {
        return $this->getAppUrl() . '/auth/logout';
    }

    public function getForgotPasswordUrl()
    {
        return $this->getAppUrl() . '/auth#forgot-password';
    }

    public function getVerifyUrl()
    {
        return $this->getAppUrl() . '/wizard/verify';
    }

    public function getWizardUrl()
    {
        return $this->getAppUrl() . '/wizard';
    }

    public function getDashboardUrl()
    {
        return $this->getAppUrl() . '/dashboard';
    }

    public function getDownLoadBridgeUrl($cms2cms_authentication)
    {
        return $this->getAppUrl() . '/wizard/get-bridge?callback=plugin&authentication=' . urlencode(json_encode($cms2cms_authentication));
    }

}
