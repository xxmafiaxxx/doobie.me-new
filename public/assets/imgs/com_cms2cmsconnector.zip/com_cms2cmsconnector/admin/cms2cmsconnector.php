<?php
/**
 * @package    Joomla.Tutorials
 * @subpackage Components
 * components/com_hello/hello.php
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_1
 * @license    GNU/GPL
*/
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

define('CMS2CMS_VERSION', '2.0.0');

if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

// Require the base controller

require_once(JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'controller.php');
include JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR  . 'data.php';
include JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR  . 'view.php';
include JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR  .'cms2cms-bridge-loader.php';

// Create the controller
$classname    = 'CmsController';
$controller   = new $classname( );
 
// Perform the Request task
$controller->execute(JFactory::getApplication()->input->get('task'));
 
// Redirect if set by the controller
$controller->redirect($path);
