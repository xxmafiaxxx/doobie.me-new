<?php
/**
 * @package   AkeebaBackup
 * @copyright Copyright (c)2006-2017 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

class Com_Cms2cmsconnectorInstallerScript
{

    /**
     * Method to uninstall the extension
     * $parent is the class calling this method
     *
     * @return void
     */
    function uninstall($parent)
    {
        if(JFolder::exists(JPATH_ROOT . '/cms2cms')) {
            JFolder::delete(JPATH_ROOT . '/cms2cms');
        }

    }

}
