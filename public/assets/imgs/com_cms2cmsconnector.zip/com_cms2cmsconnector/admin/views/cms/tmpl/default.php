<?php
/**
 * @copyright	Copyright (C) 2013 - 2017 Cms2Cms. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

if ( !defined('CMS2CMS_VERSION') ) {
    die();
}
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_cms2cmsconnector/css/cms2cms.css');
$document->addScript('https://code.jquery.com/jquery-1.9.0.min.js');
$document->addScript('components/com_cms2cmsconnector/js/cms2cms.js', "text/javascript", true);
$document->addScript('components/com_cms2cmsconnector/js/jsonp.js', "text/javascript", true);

$dataProvider = new CmsPluginData();
$viewProvider = new CmsPluginView();
$loader       = new CmsBridgeLoader();
$dataProvider->logOut();

$cms2cms_access_key      = $dataProvider->getOption('cms2cms-key');
$cms2cms_is_activated    =  $dataProvider->isActivated();
$cms2cms_target_url      = $dataProvider->getSiteUrl();
$cms2cms_bridge_url      = $dataProvider->getBridgeUrl();
$cms2cms_authentication  = $dataProvider->getAuthData();
$cms2cms_download_bridge = $viewProvider->getDownLoadBridgeUrl($cms2cms_authentication);
$jsConfig  = $viewProvider->getConfig(true);
$config    = $viewProvider->getConfig();
$fileStart = 'cms2cms-migration';

try {
    $loader->checkKey($cms2cms_access_key, $config['bridge']);
} catch (\Exception $exception) {
    $message = $exception->getMessage();
}

?>
<div class="wrap">
    <div class="cms2cms-joomla-container">
        <div id="cms_overlay">
            <div class="circle-an">
                <span class="dot no1"></span>
                <span class="dot no2"></span>
                <span class="dot no3"></span>
                <span class="dot no4"></span>
                <span class="dot no5"></span>
                <span class="dot no6"></span>
                <span class="dot no7"></span>
                <span class="dot no8"></span>
                <span class="dot no9"></span>
                <span class="dot no10"></span>
            </div>
        </div>
        <div class="cms2cms-joomla-header">
            <img src="<?php echo $dataProvider->getAdminUrl(); ?>/img/cms2cms-logo.png" alt="CMS2CMS Logo"
                 title="CMS2CMS - Migrate your website content to a new CMS or forum in a few easy steps"/>
        </div>
        <script language="JavaScript">
            var config = <?php echo $jsConfig?>
        </script>
        <?php if ($cms2cms_is_activated) { ?>
            <script language="JavaScript">
                jQuery('.cms2cms-joomla-container').addClass('cms2cms_joomla_is_activated');
            </script>
            <div class="cms2cms-joomla-message">
                <span>
                    <?php echo sprintf(
                        'You are logged in CMS2CMS as %s',
                        $dataProvider->getOption('cms2cms-login')
                    ); ?>
                </span>
                <div class="cms2cms-joomla-logout">
                    <form action="" method="post" id="logout" data-logout="<?php echo $viewProvider->getLogOutUrl() ?>">
                        <input type="hidden" name="task" value="clear-auth"/>
                        <input type="hidden" name="cms2cms_joomla_logout" value="1"/>
                        <input type="hidden" name="_wpnonce"
                               value="<?php echo true ?>"/>
                        <button class="button-grey cms2cms-joomla-button" data-log-this="Logout" type="button">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        <?php } ?>
        <div class="cms2cms-joomla-plugin">
            <div id="cms2cms_joomla_accordeon">
                <h3 class="step step-sign active">
                    <div class="step-numb-block"><i>1</i></div>
                    <b></b>
                    <h id="signIn">Sign In</h>
                    <h id="signUp" style="display: none">Sign Up</h>
                    <span class="spinner"></span>
                </h3>
                <?php
                $cms2cms_joomla_step_counter = 1;
                if (!$cms2cms_is_activated) { ?>
                    <div id="cms2cms_joomla_accordeon_item_id_<?php echo $cms2cms_joomla_step_counter++; ?>"
                         class="step-body cms2cms_joomla_accordeon_item cms2cms_joomla_accordeon_item_register">
                        <?php if (isset($message)) {?>
                            <div class="container-erorr-1">
                                <div class="block-erorr alertcms r-b-e">
                                    <?php sprintf('%s Please contact our', $message); ?>
                                    <a href="http://support.magneticone.com/visitor/index.php?/Default/LiveChat/Chat/Request/_sessionID=/_promptType=chat/_proactive=0/_filterDepartmentID=55/_randomNumber=bnkpattsb316qulj4o15lvdbkq6qsw53">support team.</a>
                                </div>
                            </div>
                        <?php } ?>
                        <form action="<?php echo $viewProvider->getLoginUrl() ?>"
                              callback="callback_auth"
                              validate="auth_check_password"
                              class="step_form"
                              id="cms2cms_joomla_form_register">
                            <div class="center-content">
                                <div class="error_message"></div>
                                <div class="user-name-block" style="display: none">
                                    <label
                                        for="cms2cms-joomla-user-name" class="label-text">Full Name</label>
                                    <input type="text" maxlength="50" id="cms2cms-joomla-user-name" name="name"
                                           value="" placeholder="Your name" class="regular-text"/>
                                    <div class="cms2cms-joomla-error name">
                                        <div class="error-arrow"></div>
                                        <span></span></div>
                                </div>
                                <div>
                                    <label
                                        for="cms2cms-joomla-user-email" class="label-text">Email</label>
                                    <input type="text" id="cms2cms-joomla-user-email" name="email"
                                           value="" placeholder="Your email" class="regular-text"/>
                                    <div class="cms2cms-joomla-error email">
                                        <div class="error-arrow"></div>
                                        <span></span></div>
                                </div>
                                <div>
                                    <label
                                        for="cms2cms-joomla-user-password" class="label-text">Password</label>
                                    <input type="password" id="cms2cms-joomla-user-password" name="password" value=""
                                           placeholder="Your password" class="regular-text"/>
                                    <div class="cms2cms-joomla-error password">
                                        <div class="error-arrow"></div>
                                        <span></span></div>
                                </div>

                                <input type="hidden" id="cms2cms-joomla-user-plugin" name="referrer"
                                       value="<?php echo $viewProvider->getPluginReferrerId(); ?>"
                                       class="regular-text"/>
                                <input type="hidden" id="cms2cms-joomla-site-url" name="siteUrl"
                                       value="<?php echo $cms2cms_target_url; ?>"/>
                                <input type="hidden" name="termsOfService" value="1">
                                <input type="hidden" id="loginUrl" name="login-url"
                                       value="<?php echo $viewProvider->getLoginUrl() ?>">
                                <input type="hidden" id="registerUrl" name="login-register"
                                       value="<?php echo $viewProvider->getRegisterUrl() ?>">
                                <button
                                    data-log-this="Authorization..."
                                    type="button" id="auth_submit" class="cms2cms-joomla-button button-green">
                                    Continue
                                </button>
                                <a data-log-this="Forgot Password Link clicked"
                                   href="<?php echo $viewProvider->getForgotPasswordUrl() ?>"
                                   class="cms2cms-joomla-real-link" >Forgot password</a>
                                <p class="account-register">Don't have an account yet?
                                    <a class="login-reg">Register</a></p>
                                <p class="account-login">Already have an account?
                                    <a class="login-reg">Login</a></p>
                            </div>
                    </div>
                    <div></form></div>
                <?php } /* cms2cms_joomla_is_activated */ ?>
                <h3 class="step step-connect">
                    <div class="step-numb-block"><i>2</i></div>
                    <b></b>
                    <?php echo 'Connect'; ?>
                    <span class="spinner"></span>
                </h3>
                <div id="cms2cms_joomla_accordeon_item_id_<?php echo $cms2cms_joomla_step_counter++; ?>"
                     class="step-body cms2cms_joomla_accordeon_item">
                    <form id="cms2cms_joomla_form">
                        <input type="hidden" id="key" name="key" value="<?php echo $cms2cms_access_key; ?>"/>
                        <?php if (isset($message)) {?>
                            <div class="container-erorr-1">
                                <div class="block-erorr alertcms r-b-e">
                                    <?php echo sprintf('%s Please contact our', $message); ?>
                                    <a href="http://support.magneticone.com/visitor/index.php?/Default/LiveChat/Chat/Request/_sessionID=/_promptType=chat/_proactive=0/_filterDepartmentID=55/_randomNumber=bnkpattsb316qulj4o15lvdbkq6qsw53">support team.</a>
                                </div>
                            </div>
                        <?php } else { ?>
                            <div class="center-content">The bridge has been successfully installed. You can proceed with your migration.<br>
                                <button id="verifySource_joomla" onclick="location.href='<?php echo $viewProvider->getDashboardUrl(); ?>'"
                                        type="button" name="verify-source" class="cms2cms-joomla-button button-green distance-button-j">
                                    Proceed
                                </button>
                            </div>
                        <?php } ?>
                    </form>
                    <div class="cms2cms-joomla-error"></div>
                </div>
            </div>
        </div> <!-- /plugin -->
        <!-- Support block -->
        <div class="support-block">
            <div class="cristine"></div>
            <div class="supp-bg supp-info supp-need-help">
                <div class="arrow-left"></div>
                <div class="need-help-blocks size13">
                    <div class="need-help-block">
                        <h3> Need help?</h3>
                        Get all your questions answered!<br>
                        <a href="http://support.magneticone.com/visitor/index.php?/Default/LiveChat/Chat/Request/_sessionID=/_promptType=chat/_proactive=0/_filterDepartmentID=55/_randomNumber=bnkpattsb316qulj4o15lvdbkq6qsw53">Chat Now!</a>
                    </div>
                    <div class="feed-back-block">
                        <h3> Got Feedback?</h3>
                        - <a
                            href="<?php echo $config['wp_feedback'] ?>">Write a review</a><br/>
                        - Follow us on <a href="<?php echo $config['twitter'] ?>">Twitter</a> or
                        <a href="<?php echo $config['facebook'] ?>">Facebook</a>
                    </div>
                </div>
            </div>
            <div class="supp-bg supp-info packages-block size13">Have specific data migration needs?
                <h3>Choose one of our<br/><a href="<?php echo $config['public_host'] ?>/support-service-plans/">Support Service Packages</a>
                </h3>
            </div>
        </div>
        <div class="cms2cms-joomla-footer cms2cms-joomla-plugin position-m-block">
            <a href="<?php echo $config['public_host'] ?>/how-it-works/">How It Works</a>
            <a href="<?php echo $config['public_host'] ?>/faqs/">FAQs</a>
            <a href="<?php echo $config['public_host'] ?>/blog/">Blog</a>
            <a href="<?php echo $config['public_host'] ?>/terms-of-service/">Terms</a>
            <a href="<?php echo $config['public_host'] ?>/privacy-policy/">Privacy</a>
            <a href="<?php echo $config['ticket'] ?>">Submit a Ticket</a>
        </div>

    </div>
</div> <!-- /wrap -->